package com.iiht.evaluation.eloan.dto;

public class AdminDTO {

}
