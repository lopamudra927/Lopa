package com.iiht.evaluation.eloan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.iiht.evaluation.eloan.controller.AdminController;
import com.iiht.evaluation.eloan.controller.UserController;
import com.iiht.evaluation.eloan.dto.LoanDto;
import com.iiht.evaluation.eloan.model.LoanInfo;
import com.wellsfargo.batch5.lms.exception.LibraryException;
import com.wellsfargo.batch5.lms.model.Book;

public class AdminDao {
	
	public static final String SELECT_ALL_QRY=
			"SELECT applno,purpose,amtrequest,doa,bstructure,bindicator,address,email,mobile,status FROM LoanInfo";
	public static final String UPD_Status_QRY=
			"UPDATE LoanInfo SET status=?, WHERE applno=?";
	
		public static List<LoanInfo> listAll(){
		List<LoanInfo> loans=new ArrayList<>();
		try {
			ConnectionDao conn = AdminController.getConnDao();
			Connection con = conn.connect();
			PreparedStatement pst = con.prepareStatement(SELECT_ALL_QRY);
		
							
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				LoanInfo loanInfo = new LoanInfo();
				loanInfo.setApplno(rs.getString(1));
				loanInfo.setPurpose(rs.getString(2));
				loanInfo.setAmtrequest(rs.getInt(3));
				loanInfo.setDoa(rs.getString(4));
				loanInfo.setBstructure(rs.getString(5));
				loanInfo.setBindicator(rs.getString(6));
				loanInfo.setAddress(rs.getString(7));
				loanInfo.setEmail(rs.getString(8));
				loanInfo.setMobile(rs.getString(9));
				loanInfo.setStatus(rs.getString(10));
				
				loans.add(loanInfo);
			}
						
		}catch(SQLException exp) {
			
		}
		return loans;
	}

		public static LoanInfo updateLoanStatus(int loanApplicationNumber ) {
			LoanInfo loanInfo = new LoanInfo();
			try {
				ConnectionDao conn = AdminController.getConnDao();
				Connection con = conn.connect();
				PreparedStatement pst = con.prepareStatement(UPD_Status_QRY);
				pst.setString(1, loanInfo.getStatus());
				pst.executeUpdate();
			
			
		}catch(SQLException exp) {
			
		}
			return loanInfo;
		}

	
		public static void process() {
			// TODO Auto-generated method stub
			
		}

		

		




}
